<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:62:"D:\phpstudy\WWW\jddemo\public/../api/admin\view\block\add.html";i:1572488830;s:46:"D:\phpstudy\WWW\jddemo\api\admin\view\out.html";i:1571134800;}*/ ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Access-Control-Allow-Origin" content="*">
    <title>几度CMS管理后台</title>
    <link href="/static/assets/css/bootstrap.css" rel="stylesheet" />
    <link href="/static/assets/css/font-awesome.css" rel="stylesheet" />
    <link href="/static/assets/css/basic.css" rel="stylesheet" />
    <link href="/static/assets/css/custom.css" rel="stylesheet" />
    <link href="/static/assets/css/bootstrap-fileupload.min.css" rel="stylesheet"/>
    <script src="/static/assets/js/jquery-1.10.2.js"></script>
    <script src="/static/assets/js/bootstrap.js"></script>
    <script src="/static/assets/js/jquery.metisMenu.js"></script>
    <script src="/static/assets/js/custom.js"></script>
    <script src="/static/assets/js/bootstrap-fileupload.js"></script>
    <script src="/static/assets/js/jquery.metisMenu.js"></script>
    <script src="/static/plug/layer/layer.js" type="text/javascript"></script>
</head>
<body>
<div id="wrapper">
    <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <!-- 手机端样式 -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- 手机端样式 end-->
            <a class="navbar-brand" href="<?php echo url('admin/Index/index'); ?>">管理员后台</a>
        </div>

        <div class="header-right">
            <a href="<?php echo url('Admin/info'); ?>" class="btn btn-primary">管理员：<?php echo $admin['name']; ?></a>
            |
            <a class="btn btn-danger" Onclick="out();" title="Logout">退出登录</a>
        </div>
    </nav>

    <!-- 左侧导航 start -->
    <nav class="navbar-default navbar-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="main-menu">
                <?php if(is_array($nav) || $nav instanceof \think\Collection || $nav instanceof \think\Paginator): $i = 0; $__LIST__ = $nav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;if(empty($v['child']) || (($v['child'] instanceof \think\Collection || $v['child'] instanceof \think\Paginator ) && $v['child']->isEmpty())): ?>
                <li>
                    <a class="a-menu" data-id="<?php echo $v['id']; ?>" href="<?php echo url('admin/'.$v['c'].'/'.$v['a']); ?>"><i class="<?php echo $v['css']; ?>"></i><?php echo $v['name']; ?></a>
                </li>
                <?php else: ?>
                <li class="a-parent">
                    <a href="#"><i class="fa fa-book "></i><?php echo $v['name']; ?><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <?php if(is_array($v['child']) || $v['child'] instanceof \think\Collection || $v['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $v['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
                        <li>
                            <a class="a-menu" data-id="<?php echo $v['id']; ?>" href="<?php echo url($vv['c'].'/'.$vv['a']); ?>"><i class="<?php echo $vv['css']; ?>"></i><?php echo $vv['name']; ?></a>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </li>
                <?php endif; endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
    </nav>
    <!-- 左侧导航 end -->

    <!-- 内容 -->
    <div id="page-wrapper">
        <div id="page-inner">
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-info">
            <div class="panel-heading">
                添加自定义块
            </div>
            <div class="panel-body">
                <form action="<?php echo url('add', ['cat'=>\think\Request::instance()->param('cat')]); ?>" method="post" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>名称</label>
                        <input name="name" type="text" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>英文标识</label>
                        <input name="tag" type="text" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>描述说明</label>
                        <input name="remark" type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>分类</label>
                        <select name="cid" class="form-control">
                            <?php if(is_array($cat) || $cat instanceof \think\Collection || $cat instanceof \think\Paginator): $i = 0; $__LIST__ = $cat;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
                            <option value="<?php echo $v['id']; ?>"><?php echo $v['name']; ?></option>
                            <?php endforeach; endif; else: echo "" ;endif; ?>
                        </select>
                    </div>
                    <div class="form-group">
                        <label>类型</label>
                        <select name="type" class="form-control content-type">
                            <option value="1">文字</option>
                            <option value="2">图片</option>
                            <option value="3">富文本</option>
                        </select>
                    </div>

                    <div class="form-group content-1"  style="display: none;">
                        <label>内容</label>
                        <textarea name="content1" class="form-control"></textarea>
                    </div>
                    <div class="form-group content-2">
                        <label class="control-label">内容</label>
                        <input name="content2" type="text" class="form-control img-text">

                        <!-- 直接上传 -->
                        <input class="form-control img-single" type="file" name="img" style="margin-top: 10px; width: 10%;"> 

                        <!-- 站内图片 -->
                        <span class="btn btn-primary img-select" style="margin-top: 10px;">选择站内图片</span>
                        <div class="show-all-img" style="margin: 20px 0;"></div>
                    </div>
                    <div class="form-group content-3"  style="display: none;">
                        <label>内容</label>
                        <!-- 引入百度编辑器 -->
                        <script type="text/javascript" charset="utf-8" src="/static/plug/ue/ueditor.config.js"></script>
                        <script type="text/javascript" charset="utf-8" src="/static/plug/ue/ueditor.all.min.js"></script>
                        <script type="text/javascript" charset="utf-8" src="/static/plug/ue/lang/zh-cn/zh-cn.js"></script>
                        <script id="editor" type="text/plain" style="width:100%; height: 200px;"></script>
                        <script> var ue = UE.getEditor('editor'); </script>
                    </div>

                    <div class="form-group">
                        <label>链接</label>
                        <input name="url" type="text" class="form-control">
                    </div>

                    <button name="sub" value="1" type="submit" class="btn btn-info" style="margin-right: 40px;"> 保 存 </button>
                    <a href="<?php echo url('index', ['cat'=>\think\Request::instance()->param('cat')]); ?>" class="btn btn-warning"> 返 回 </a>
                </form>
               
            </div>
        </div>
    </div>
</div>

<script>
    $(".content-type").on("change", function () {
        var type = $(this).val();

        if (type == 1) {
            $(".content-1").show();
            $(".content-2").hide();
            $(".content-3").hide();
        } else if (type == 2) {
            $(".content-1").hide();
            $(".content-2").show();
            $(".content-3").hide();
        } else if (type == 3) {
            $(".content-1").hide();
            $(".content-2").hide();
            $(".content-3").show();
        }
    })

    $(".img-single").on("change", function () {
        var formData = new FormData($("form")[0]);
        $.ajax({
            url : "<?php echo url('Upload/imgSingle'); ?>",
            type: "post",
            data: formData,
            cache: false,
            processData: false,
            contentType: false,
            success: function (res) {
                if (res.status == 1) {
                    $(".img-text").val(res.data);
                } else {
                    layer.msg(res.msg, {time: 1000});
                }
            }
        });
    })

    $(".img-select").on("click", function () {
        $.post("<?php echo url('Upload/fileMag'); ?>", '', function (res) {
            var txt = '';
            var list = res.data.infolist;
            for (var i=0; i<list.length; i++) {
                txt += "<p><a style='cursor: pointer;' class='img-show' data-href='"+list[i]['url']+"'>"+list[i]['filename']+"</a></p>";
            }
            $(".show-all-img").html(txt);
        })
    })

    $(document).on("click", ".img-show", function () {
        var url = $(this).attr("data-href");
        $.post(url, '', function (res) {
            var txt;
            var prev = res.data.purl;   // 上级地址
            txt = "<p><a style='cursor: pointer;' class='go-prev' data-href='"+prev+"'>返回上一级</a></p>";
            var list = res.data.infolist;
            for (var i=0; i<list.length; i++) {
                txt += "<img class='find-img' src='"+list[i]['url']+"' data-src='"+list[i]['url']+"' alt='"+list[i]['filename']+"' title='"+list[i]['filename']+"' style='width: 100px; height: 100px; margin-right: 10px;'>";
            }
            $(".show-all-img").html(txt);
        })
    })

    $(document).on("click", ".go-prev", function () {
        $.post("<?php echo url('Upload/fileMag'); ?>", '', function (res) {
            var txt = '';
            var list = res.data.infolist;
            for (var i=0; i<list.length; i++) {
                txt += "<p><a style='cursor: pointer;' class='img-show' data-href='"+list[i]['url']+"'>"+list[i]['filename']+"</a></p>";
            }
            $(".show-all-img").html(txt);
        })
    })

    $(document).on("click", ".find-img", function () {
        $(".img-text").val($(this).attr("data-src"));
    })
</script></div>
    </div>
    <!-- 内容 end -->
</div>

<!-- 底部版权 -->
<div id="footer-sec">
    版权所有：几度CMS
</div>
<!-- 底部版权 end -->


<script>
    //菜单选中JS
    var nowUrl = location.href;
    $(".a-menu").each(function () {
        var that = $(this);
        var theUrl = "http://"+"<?php echo $_SERVER['HTTP_HOST']; ?>"+that.attr('href');
        if(nowUrl.indexOf(that.attr('href')) >= 0 ) { 
            that.addClass('active-menu');
            that.parents('.a-parent').addClass('active');
        }
    })

    //退出系统
    function out() {
        layer.confirm('确认退出吗？',function(){
            location.href = '<?php echo url('Login/out'); ?>';
        })
    }
</script>
</body>
</html>