<?php if (!defined('THINK_PATH')) exit(); /*a:2:{s:65:"D:\phpstudy\WWW\jddemo\public/../api/admin\view\diymode\edit.html";i:1572511667;s:46:"D:\phpstudy\WWW\jddemo\api\admin\view\out.html";i:1571134800;}*/ ?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Access-Control-Allow-Origin" content="*">
    <title>几度CMS管理后台</title>
    <link href="/static/assets/css/bootstrap.css" rel="stylesheet" />
    <link href="/static/assets/css/font-awesome.css" rel="stylesheet" />
    <link href="/static/assets/css/basic.css" rel="stylesheet" />
    <link href="/static/assets/css/custom.css" rel="stylesheet" />
    <link href="/static/assets/css/bootstrap-fileupload.min.css" rel="stylesheet"/>
    <script src="/static/assets/js/jquery-1.10.2.js"></script>
    <script src="/static/assets/js/bootstrap.js"></script>
    <script src="/static/assets/js/jquery.metisMenu.js"></script>
    <script src="/static/assets/js/custom.js"></script>
    <script src="/static/assets/js/bootstrap-fileupload.js"></script>
    <script src="/static/assets/js/jquery.metisMenu.js"></script>
    <script src="/static/plug/layer/layer.js" type="text/javascript"></script>
</head>
<body>
<div id="wrapper">
    <nav class="navbar navbar-default navbar-cls-top " role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <!-- 手机端样式 -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".sidebar-collapse">
                <span class="sr-only">Toggle navigation</span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
            <!-- 手机端样式 end-->
            <a class="navbar-brand" href="<?php echo url('admin/Index/index'); ?>">管理员后台</a>
        </div>

        <div class="header-right">
            <a href="<?php echo url('Admin/info'); ?>" class="btn btn-primary">管理员：<?php echo $admin['name']; ?></a>
            |
            <a class="btn btn-danger" Onclick="out();" title="Logout">退出登录</a>
        </div>
    </nav>

    <!-- 左侧导航 start -->
    <nav class="navbar-default navbar-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav" id="main-menu">
                <?php if(is_array($nav) || $nav instanceof \think\Collection || $nav instanceof \think\Paginator): $i = 0; $__LIST__ = $nav;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;if(empty($v['child']) || (($v['child'] instanceof \think\Collection || $v['child'] instanceof \think\Paginator ) && $v['child']->isEmpty())): ?>
                <li>
                    <a class="a-menu" data-id="<?php echo $v['id']; ?>" href="<?php echo url('admin/'.$v['c'].'/'.$v['a']); ?>"><i class="<?php echo $v['css']; ?>"></i><?php echo $v['name']; ?></a>
                </li>
                <?php else: ?>
                <li class="a-parent">
                    <a href="#"><i class="fa fa-book "></i><?php echo $v['name']; ?><span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">
                        <?php if(is_array($v['child']) || $v['child'] instanceof \think\Collection || $v['child'] instanceof \think\Paginator): $i = 0; $__LIST__ = $v['child'];if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$vv): $mod = ($i % 2 );++$i;?>
                        <li>
                            <a class="a-menu" data-id="<?php echo $v['id']; ?>" href="<?php echo url($vv['c'].'/'.$vv['a']); ?>"><i class="<?php echo $vv['css']; ?>"></i><?php echo $vv['name']; ?></a>
                        </li>
                        <?php endforeach; endif; else: echo "" ;endif; ?>
                    </ul>
                </li>
                <?php endif; endforeach; endif; else: echo "" ;endif; ?>
            </ul>
        </div>
    </nav>
    <!-- 左侧导航 end -->

    <!-- 内容 -->
    <div id="page-wrapper">
        <div id="page-inner">
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-info">
            <div class="panel-body">
                <form <?php if($info){ ?> action="<?php echo url('edit',array('id'=>$info['id'])); ?>" <?php }else{ ?>action="<?php echo url('add'); ?>"<?php }?>  method='post' enctype="multipart/form-data">
                    <div class="form-group">
                        <label>模型名称</label>
                        <input name="name" value="<?php echo $info['name']; ?>" type="text" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>数据表名</label>
                        <input name="table_name" value="<?php echo $info['table_name']; ?>" type="text" class="form-control" required>
                    </div>
                    <div class="form-group">
                        <label>描述说明</label>
                        <input name="remark" value="<?php echo $info['remark']; ?>" type="text" class="form-control">
                    </div>
                    <div class="form-group">
                        <label>排序</label>
                        <input name="rank" value="<?php echo $info['rank']; ?>" type="number" class="form-control">
                    </div>
                    <button  name="sub" value='1' type="submit" class="btn btn-info" style="margin-right: 40px;"> 保 存 </button>
                    <a href="<?php echo url('index'); ?>" class="btn btn-warning"> 返 回 </a>
                </form>
            </div>
        </div>
    </div>
    <script>

    </script>
</div></div>
    </div>
    <!-- 内容 end -->
</div>

<!-- 底部版权 -->
<div id="footer-sec">
    版权所有：几度CMS
</div>
<!-- 底部版权 end -->


<script>
    //菜单选中JS
    var nowUrl = location.href;
    $(".a-menu").each(function () {
        var that = $(this);
        var theUrl = "http://"+"<?php echo $_SERVER['HTTP_HOST']; ?>"+that.attr('href');
        if(nowUrl.indexOf(that.attr('href')) >= 0 ) { 
            that.addClass('active-menu');
            that.parents('.a-parent').addClass('active');
        }
    })

    //退出系统
    function out() {
        layer.confirm('确认退出吗？',function(){
            location.href = '<?php echo url('Login/out'); ?>';
        })
    }
</script>
</body>
</html>