<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:64:"D:\phpstudy\WWW\jddemo\public/../api/index\view\index\index.html";i:1572401966;}*/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>index</title>
</head>
<body>
    <?php if(is_array($arr) || $arr instanceof \think\Collection || $arr instanceof \think\Paginator): $i = 0; $__LIST__ = $arr;if( count($__LIST__)==0 ) : echo "" ;else: foreach($__LIST__ as $key=>$v): $mod = ($i % 2 );++$i;?>
        <p>id: <?php echo $v['id']; ?>, name: <?php echo $v['name']; ?></p>
    <?php endforeach; endif; else: echo "" ;endif; ?>
</body>
</html>