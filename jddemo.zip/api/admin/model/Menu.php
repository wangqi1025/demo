<?php
// +----------------------------------------------------------------------
// | JDCMS V1.2
// +----------------------------------------------------------------------
// | Author: WANGQI <email:wq@ji-du.com.cn>
// +----------------------------------------------------------------------
namespace app\admin\model;

use think\Model;

class Menu extends Model
{
	protected $name = 'admin_menu';
}