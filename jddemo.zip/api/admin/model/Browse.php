<?php
// +----------------------------------------------------------------------
// | JDCMS V1.2
// +----------------------------------------------------------------------
// | Author: WANGQI <email:wq@ji-du.com.cn>
// +----------------------------------------------------------------------
namespace app\admin\model;

use think\Model;

class Browse extends Model
{
	protected $name = 'browse';
}